/*
   +----------------------------------------------------------------------+
   | PHP Version 4                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997-2008 The PHP Group                                |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@zend.com>                                |
   |          Sascha Schumann <sascha@schumann.cx>                        |
   +----------------------------------------------------------------------+
*/

/* $Id: tsrm_virtual_cwd.c,v 1.41.2.11.2.6 2007/12/31 07:22:45 sebastian Exp $ */

#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <errno.h>
#include <stdlib.h>
#include <fcntl.h>

#include "tsrm_virtual_cwd.h"
#include "tsrm_strtok_r.h"

#ifdef TSRM_WIN32
#include <io.h>
#include "tsrm_win32.h"
#endif

#ifdef NETWARE
#include <fsio.h>
#endif

#ifndef HAVE_REALPATH
#define realpath(x,y) strcpy(y,x)
#endif

#define VIRTUAL_CWD_DEBUG 0

#include "TSRM.h"

/* Only need mutex for popen() in Windows and NetWare, because it doesn't chdir() on UNIX */
#if (defined(TSRM_WIN32) || defined(NETWARE)) && defined(ZTS)
MUTEX_T cwd_mutex;
#endif

#ifdef ZTS
static ts_rsrc_id cwd_globals_id;
#else
static virtual_cwd_globals cwd_globals;
#endif

cwd_state main_cwd_state; /* True global */

#ifndef TSRM_WIN32
#include <unistd.h>
#else
#include <direct.h>
#endif

#ifndef S_ISDIR
#define S_ISDIR(mode) ((mode) & _S_IFDIR)
#endif

#ifndef S_ISREG
#define S_ISREG(mode) ((mode) & _S_IFREG)
#endif

#ifdef TSRM_WIN32
#include <tchar.h>
#define tsrm_strtok_r(a,b,c) _tcstok((a),(b))
#define TOKENIZER_STRING "/\\"
	
static int php_check_dots(const char *element, int n) 
{
	while (n-- > 0) if (element[n] != '.') break;

	return (n != -1);
}
	
#define IS_DIRECTORY_UP(element, len) \
	(len >= 2 && !php_check_dots(element, len))

#define IS_DIRECTORY_CURRENT(element, len) \
	(len == 1 && element[0] == '.')

#elif defined(NETWARE)
/* NetWare has strtok() (in LibC) and allows both slashes in paths, like Windows --
   but rest of the stuff is like Unix */
/* strtok() call in LibC is abending when used in a different address space -- hence using
   PHP's version itself for now */
/*#define tsrm_strtok_r(a,b,c) strtok((a),(b))*/
#define TOKENIZER_STRING "/\\"

#else
#define TOKENIZER_STRING "/"
#endif


/* default macros */

#ifndef IS_DIRECTORY_UP
#define IS_DIRECTORY_UP(element, len) \
	(len == 2 && element[0] == '.' && element[1] == '.')
#endif

#ifndef IS_DIRECTORY_CURRENT
#define IS_DIRECTORY_CURRENT(element, len) \
	(len == 1 && element[0] == '.')
#endif

/* define this to check semantics */
#define IS_DIR_OK(s) (1)
	
#ifndef IS_DIR_OK
#define IS_DIR_OK(state) (php_is_dir_ok(state) == 0)
#endif


#define CWD_STATE_COPY(d, s)				\
	(d)->cwd_length = (s)->cwd_length;		\
	(d)->cwd = (char *) malloc((s)->cwd_length+1);	\
	memcpy((d)->cwd, (s)->cwd, (s)->cwd_length+1);

#define CWD_STATE_FREE(s)			\
	free((s)->cwd);
	
static int php_is_dir_ok(const cwd_state *state) 
{
	struct stat buf;

	if (stat(state->cwd, &buf) == 0 && S_ISDIR(buf.st_mode))
		return (0);

	return (1);
}

static int php_is_file_ok(const cwd_state *state) 
{
	struct stat buf;

	if (stat(state->cwd, &buf) == 0 && S_ISREG(buf.st_mode))
		return (0);

	return (1);
}

static void cwd_globals_ctor(virtual_cwd_globals *cwd_globals TSRMLS_DC)
{
	CWD_STATE_COPY(&cwd_globals->cwd, &main_cwd_state);
}

static void cwd_globals_dtor(virtual_cwd_globals *cwd_globals TSRMLS_DC)
{
	CWD_STATE_FREE(&cwd_globals->cwd);
}

static char *tsrm_strndup(const char *s, size_t length)
{
    char *p;

    p = (char *) malloc(length+1);
    if (!p) {
        return (char *)NULL;
    }
    if (length) {
        memcpy(p,s,length);
    }
    p[length]=0;
    return p;
}

#if SUHOSIN_PATCH
CWD_API char *php_realpath(const char *path, char *resolved)
{
        struct stat sb;
        char *p, *q, *s;
        size_t left_len, resolved_len;
        unsigned symlinks;
        int serrno, slen;
        int is_dir = 1;
        char left[PATH_MAX], next_token[PATH_MAX], symlink[PATH_MAX];

        serrno = errno;
        symlinks = 0;
        if (path[0] == '/') {
                resolved[0] = '/';
                resolved[1] = '\0';
                if (path[1] == '\0')
                        return (resolved);
                resolved_len = 1;
                left_len = strlcpy(left, path + 1, sizeof(left));
        } else {
                if (getcwd(resolved, PATH_MAX) == NULL) {
                        strlcpy(resolved, ".", PATH_MAX);
                        return (NULL);
                }
                resolved_len = strlen(resolved);
                left_len = strlcpy(left, path, sizeof(left));
        }
        if (left_len >= sizeof(left) || resolved_len >= PATH_MAX) {
                errno = ENAMETOOLONG;
                return (NULL);
        }

        /*
         * Iterate over path components in `left'.
         */
        while (left_len != 0) {
                /*
                 * Extract the next path component and adjust `left'
                 * and its length.
                 */
                p = strchr(left, '/');
                s = p ? p : left + left_len;
                if (s - left >= sizeof(next_token)) {
                        errno = ENAMETOOLONG;
                        return (NULL);
                }
                memcpy(next_token, left, s - left);
                next_token[s - left] = '\0';
                left_len -= s - left;
                if (p != NULL)
                        memmove(left, s + 1, left_len + 1);
                if (resolved[resolved_len - 1] != '/') {
                        if (resolved_len + 1 >= PATH_MAX) {
                                errno = ENAMETOOLONG;
                                return (NULL);
                        }
                        resolved[resolved_len++] = '/';
                        resolved[resolved_len] = '\0';
                }
                if (next_token[0] == '\0')
                        continue;
                else if (strcmp(next_token, ".") == 0)
                        continue;
                else if (strcmp(next_token, "..") == 0) {
                        /*
                         * Strip the last path component except when we have
                         * single "/"
                         */
                        if (!is_dir) {
                                errno = ENOENT;
                                return (NULL);
                        }
                        if (resolved_len > 1) {
                                resolved[resolved_len - 1] = '\0';
                                q = strrchr(resolved, '/');
                                *q = '\0';
                                resolved_len = q - resolved;
                        }
                        continue;
                }

                /*
                 * Append the next path component and lstat() it. If
                 * lstat() fails we still can return successfully if
                 * there are no more path components left.
                 */
                resolved_len = strlcat(resolved, next_token, PATH_MAX);
                if (resolved_len >= PATH_MAX) {
                        errno = ENAMETOOLONG;
                        return (NULL);
                }
                if (lstat(resolved, &sb) != 0) {
                        if (errno == ENOENT) {
				if (p == NULL) {
                            		errno = serrno;
                            		return (resolved);
				} else 
				/* dirty hack to support a vanilla PHP feature */
				if (strstr(left, "/.") == NULL && strstr(left, "./") == NULL) {
            				resolved_len = strlcat(resolved, "/", PATH_MAX);
            				resolved_len = strlcat(resolved, left, PATH_MAX);
            				if (resolved_len >= PATH_MAX) {
                    				errno = ENAMETOOLONG;
                    				return (NULL);
            				}
                            		errno = serrno;
                            		return (resolved);
				}
                        }
                        return (NULL);
                }
                if (S_ISLNK(sb.st_mode)) {
                        if (symlinks++ > MAXSYMLINKS) {
                                errno = ELOOP;
                                return (NULL);
                        }
                        slen = readlink(resolved, symlink, sizeof(symlink) - 1);
                        if (slen < 0)
                                return (NULL);
                        symlink[slen] = '\0';
                        if (symlink[0] == '/') {
                                resolved[1] = 0;
                                resolved_len = 1;
                        } else if (resolved_len > 1) {
                                /* Strip the last path component. */
                                resolved[resolved_len - 1] = '\0';
                                q = strrchr(resolved, '/');
                                *q = '\0';
                                resolved_len = q - resolved;
                        }

                        /*
                         * If there are any path components left, then
                         * append them to symlink. The result is placed
                         * in `left'.
                         */
                        if (p != NULL) {
                                if (symlink[slen - 1] != '/') {
                                        if (slen + 1 >= sizeof(symlink)) {
                                                errno = ENAMETOOLONG;
                                                return (NULL);
                                        }
                                        symlink[slen] = '/';
                                        symlink[slen + 1] = 0;
                                }
                                left_len = strlcat(symlink, left, sizeof(left));
                                if (left_len >= sizeof(left)) {
                                        errno = ENAMETOOLONG;
                                        return (NULL);
                                }
                        }
                        left_len = strlcpy(left, symlink, sizeof(left));
                } else {
            		if (S_ISDIR(sb.st_mode)) {
                    		is_dir = 1;
            		} else {
                    		is_dir = 0;
            		}
		}
        }

        /*
         * Remove trailing slash except when the resolved pathname
         * is a single "/".
         */
        if (resolved_len > 1 && resolved[resolved_len - 1] == '/')
                resolved[resolved_len - 1] = '\0';
        return (resolved);
}
#endif

CWD_API void virtual_cwd_startup(void)
{
	char cwd[MAXPATHLEN];
	char *result;
#ifdef NETWARE
	result = getcwdpath(cwd, NULL, 1);
	if(result)
	{
		char *c=cwd;
		while(c = strchr(c, '\\'))
		{
			*c='/';
			++c;
		}
	}
#else
	result = getcwd(cwd, sizeof(cwd));
#endif
	if (!result) {
		cwd[0] = '\0';
	}
	main_cwd_state.cwd = strdup(cwd);
	main_cwd_state.cwd_length = strlen(cwd);

#ifdef ZTS
	ts_allocate_id(&cwd_globals_id, sizeof(virtual_cwd_globals), (ts_allocate_ctor) cwd_globals_ctor, (ts_allocate_dtor) cwd_globals_dtor);
#else
	cwd_globals_ctor(&cwd_globals TSRMLS_CC);
#endif

#if (defined(TSRM_WIN32) || defined(NETWARE)) && defined(ZTS)
	cwd_mutex = tsrm_mutex_alloc();
#endif
}

CWD_API void virtual_cwd_shutdown(void)
{
#ifndef ZTS
	cwd_globals_dtor(&cwd_globals TSRMLS_CC);
#endif
#if (defined(TSRM_WIN32) || defined(NETWARE)) && defined(ZTS)
	tsrm_mutex_free(cwd_mutex);
#endif

	free(main_cwd_state.cwd); /* Don't use CWD_STATE_FREE because the non global states will probably use emalloc()/efree() */
}

CWD_API char *virtual_getcwd_ex(size_t *length TSRMLS_DC)
{
	cwd_state *state;

	state = &CWDG(cwd);

	if (state->cwd_length == 0) {
		char *retval;

		*length = 1;
		retval = (char *) malloc(2);
		retval[0] = DEFAULT_SLASH;
		retval[1] = '\0';	
		return retval;
	}

#ifdef TSRM_WIN32
	/* If we have something like C: */
	if (state->cwd_length == 2 && state->cwd[state->cwd_length-1] == ':') {
		char *retval;

		*length = state->cwd_length+1;
		retval = (char *) malloc(*length+1);
		memcpy(retval, state->cwd, *length);
		retval[*length-1] = DEFAULT_SLASH;
		retval[*length] = '\0';
		return retval;
	}
#endif
	*length = state->cwd_length;
	return strdup(state->cwd);
}


/* Same semantics as UNIX getcwd() */
CWD_API char *virtual_getcwd(char *buf, size_t size TSRMLS_DC)
{
	size_t length;
	char *cwd;

	cwd = virtual_getcwd_ex(&length TSRMLS_CC);

	if (buf == NULL) {
		return cwd;
	}
	if (length > size-1) {
		free(cwd);
		errno = ERANGE; /* Is this OK? */
		return NULL;
	}
	memcpy(buf, cwd, length+1);
	free(cwd);
	return buf;
}

/* Resolve path relatively to state and put the real path into state */
/* returns 0 for ok, 1 for error */
CWD_API int virtual_file_ex(cwd_state *state, const char *path, verify_path_func verify_path, int use_realpath)
{
	int path_length = strlen(path);
	char *ptr, *path_copy;
	char *tok = NULL;
	int ptr_length;
	cwd_state *old_state;
	int ret = 0;
	int copy_amount = -1;
	char *free_path;
	unsigned char is_absolute = 0;
#ifndef TSRM_WIN32
	char resolved_path[MAXPATHLEN];
#endif

	if (path_length == 0) 
		return (0);
	if (path_length >= MAXPATHLEN) {
                state->cwd[0] = 0;
                state->cwd_length = 0;
		return (1);
        }

#if !defined(TSRM_WIN32) && !defined(NETWARE)
	/* cwd_length can be 0 when getcwd() fails.
	 * This can happen under solaris when a dir does not have read permissions
	 * but *does* have execute permissions */
	if (IS_ABSOLUTE_PATH(path, path_length) || (state->cwd_length < 1)) {
		if (use_realpath) {
			if (realpath(path, resolved_path)) {
				path = resolved_path;
				path_length = strlen(path);
			} else {
				if (use_realpath == CWD_REALPATH) {
					state->cwd[0] = 0;
					state->cwd_length = 0;
					return 1;
				}
			}
		}
	} else { /* Concat current directory with relative path and then run realpath() on it */
		char *tmp;
		char *ptr;

		ptr = tmp = (char *) malloc(state->cwd_length+path_length+sizeof("/"));
		if (!tmp) {
                        state->cwd[0] = 0;
                        state->cwd_length = 0;
			return 1;
		}
		memcpy(ptr, state->cwd, state->cwd_length);
		ptr += state->cwd_length;
		*ptr++ = DEFAULT_SLASH;
		memcpy(ptr, path, path_length);
		ptr += path_length;
		*ptr = '\0';
		if (strlen(tmp) >= MAXPATHLEN) {
			state->cwd[0] = 0;
			state->cwd_length = 0;
			free(tmp);
			return 1;
		}
		if (use_realpath) {
			if (realpath(tmp, resolved_path)) {
				path = resolved_path;
				path_length = strlen(path);
			} else {
				if (use_realpath == CWD_REALPATH) {
					state->cwd[0] = 0;
					state->cwd_length = 0;
					free(tmp);
					return 1;
				}
			}
		}
		free(tmp);
	}
#endif
	free_path = path_copy = tsrm_strndup(path, path_length);

	old_state = (cwd_state *) malloc(sizeof(cwd_state));
	CWD_STATE_COPY(old_state, state);
#if VIRTUAL_CWD_DEBUG
	fprintf(stderr,"cwd = %s path = %s\n", state->cwd, path);
#endif
	if (IS_ABSOLUTE_PATH(path_copy, path_length)) {
        copy_amount = COPY_WHEN_ABSOLUTE(path_copy);
		is_absolute = 1;
#ifdef TSRM_WIN32
	} else if (IS_UNC_PATH(path_copy, path_length)) {
		copy_amount = 2;
		is_absolute = 1;
	} else if (IS_SLASH(path_copy[0])) {
		copy_amount = 2;
#endif
	}

	if (copy_amount != -1) {
		state->cwd = (char *) realloc(state->cwd, copy_amount + 1);
		if (copy_amount) {
			if (is_absolute) {
				memcpy(state->cwd, path_copy, copy_amount);
				path_copy += copy_amount;
			} else {
				memcpy(state->cwd, old_state->cwd, copy_amount);
			}
		}
		state->cwd[copy_amount] = '\0';
		state->cwd_length = copy_amount;
	}


	if (state->cwd_length > 0 || IS_ABSOLUTE_PATH(path, path_length)) {
		ptr = tsrm_strtok_r(path_copy, TOKENIZER_STRING, &tok);
		while (ptr) {
			ptr_length = strlen(ptr);

			if (IS_DIRECTORY_UP(ptr, ptr_length)) {
				char save;

				save = DEFAULT_SLASH;

#define PREVIOUS state->cwd[state->cwd_length - 1]

				while (IS_ABSOLUTE_PATH(state->cwd, state->cwd_length) &&
						!IS_SLASH(PREVIOUS)) {
					save = PREVIOUS;
					PREVIOUS = '\0';
					state->cwd_length--;
				}

				if (!IS_ABSOLUTE_PATH(state->cwd, state->cwd_length)) {
					state->cwd[state->cwd_length++] = save;
					state->cwd[state->cwd_length] = '\0';
				} else {
					PREVIOUS = '\0';
					state->cwd_length--;
				}
			} else if (!IS_DIRECTORY_CURRENT(ptr, ptr_length)) {
				state->cwd = (char *) realloc(state->cwd, state->cwd_length+ptr_length+1+1);
#ifdef TSRM_WIN32
				/* Windows 9x will consider C:\\Foo as a network path. Avoid it. */
				if ((state->cwd[state->cwd_length-1]!='\\' && state->cwd[state->cwd_length-1]!='/') || 
						IsDBCSLeadByte(state->cwd[state->cwd_length-2])) {
					state->cwd[state->cwd_length++] = DEFAULT_SLASH;
				}
#elif defined(NETWARE)
				/* 
					Below code keeps appending to state->cwd a File system seperator
					cases where this appending should not happen is given below,
					a) sys: should just be left as it is
					b) sys:system should just be left as it is,
					Colon is allowed only in the first token as volume names alone can have the : in their names.
					Files and Directories cannot have : in their names
					So the check goes like this,
					For second token and above simply append the DEFAULT_SLASH to the state->cwd.
					For first token check for the existence of : 
					if it exists don't append the DEFAULT_SLASH to the state->cwd.
				*/
				if(((state->cwd_length == 0) && (strchr(ptr, ':') == NULL)) || (state->cwd_length > 0))
				{
					state->cwd[state->cwd_length++] = DEFAULT_SLASH;
				}
#else
				state->cwd[state->cwd_length++] = DEFAULT_SLASH;
#endif
				memcpy(&state->cwd[state->cwd_length], ptr, ptr_length+1);
				state->cwd_length += ptr_length;
			}
			ptr = tsrm_strtok_r(NULL, TOKENIZER_STRING, &tok);
		}

		if (state->cwd_length == COPY_WHEN_ABSOLUTE(state->cwd)) {
			state->cwd = (char *) realloc(state->cwd, state->cwd_length+1+1);
			state->cwd[state->cwd_length] = DEFAULT_SLASH;
			state->cwd[state->cwd_length+1] = '\0';
			state->cwd_length++;
		}
	} else {
		state->cwd = (char *) realloc(state->cwd, path_length+1);
		memcpy(state->cwd, path, path_length+1);
		state->cwd_length = path_length;
	}

	if (verify_path && verify_path(state)) {
		CWD_STATE_FREE(state);

		*state = *old_state;

		ret = 1;
	} else {
		CWD_STATE_FREE(old_state);
		ret = 0;
	}
	
	free(old_state);
	
	free(free_path);
#if VIRTUAL_CWD_DEBUG
	fprintf (stderr, "virtual_file_ex() = %s\n",state->cwd);
#endif
	return (ret);
}

CWD_API int virtual_chdir(const char *path TSRMLS_DC)
{
	return virtual_file_ex(&CWDG(cwd), path, php_is_dir_ok, 1)?-1:0;
}

CWD_API int virtual_chdir_file(const char *path, int (*p_chdir)(const char *path TSRMLS_DC) TSRMLS_DC)
{
	int length = strlen(path);
	char *temp;
	int retval;

	if (length == 0) {
		return 1; /* Can't cd to empty string */
	}	
	while(--length >= 0 && !IS_SLASH(path[length])) {
	}

	if (length == -1) {
		/* No directory only file name */
		errno = ENOENT;
		return -1;
	}

	if (length == COPY_WHEN_ABSOLUTE(path) && IS_ABSOLUTE_PATH(path, length+1)) { /* Also use trailing slash if this is absolute */
		length++;
	}
	temp = (char *) tsrm_do_alloca(length+1);
	memcpy(temp, path, length);
	temp[length] = 0;
#if VIRTUAL_CWD_DEBUG
	fprintf (stderr, "Changing directory to %s\n", temp);
#endif
	retval = p_chdir(temp TSRMLS_CC);
	tsrm_free_alloca(temp);
	return retval;
}

CWD_API char *virtual_realpath(const char *path, char *real_path TSRMLS_DC)
{
	cwd_state new_state;
	char *retval;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	
	if (virtual_file_ex(&new_state, path, NULL, 1)==0) {
		int len = new_state.cwd_length>MAXPATHLEN-1?MAXPATHLEN-1:new_state.cwd_length;

		memcpy(real_path, new_state.cwd, len);
		real_path[len] = '\0';
		retval = real_path;
	} else {
		retval = NULL;
	}

	CWD_STATE_FREE(&new_state);

	return retval;
}

CWD_API int virtual_filepath_ex(const char *path, char **filepath, verify_path_func verify_path TSRMLS_DC)
{
	cwd_state new_state;
	int retval;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	retval = virtual_file_ex(&new_state, path, verify_path, 1);

	*filepath = new_state.cwd;

	return retval;

}

CWD_API int virtual_filepath(const char *path, char **filepath TSRMLS_DC)
{
	return virtual_filepath_ex(path, filepath, php_is_file_ok TSRMLS_CC);
}

CWD_API FILE *virtual_fopen(const char *path, const char *mode TSRMLS_DC)
{
	cwd_state new_state;
	FILE *f;

	if (path[0] == '\0') { /* Fail to open empty path */
		return NULL;
	}

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, path, NULL, 1);

	f = fopen(new_state.cwd, mode);

	CWD_STATE_FREE(&new_state);
	return f;
}

#if !defined(TSRM_WIN32)
CWD_API int virtual_access(const char *pathname, int mode TSRMLS_DC)
{
	cwd_state new_state;
	int ret;
	
	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, pathname, NULL, 1);

	ret = access(new_state.cwd, mode);
	
	CWD_STATE_FREE(&new_state);
	
	return ret;
}
#endif


#if HAVE_UTIME
CWD_API int virtual_utime(const char *filename, struct utimbuf *buf TSRMLS_DC)
{
	cwd_state new_state;
	int ret;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, filename, NULL, 0);

	ret = utime(new_state.cwd, buf);

	CWD_STATE_FREE(&new_state);
	return ret;
}
#endif

CWD_API int virtual_chmod(const char *filename, mode_t mode TSRMLS_DC)
{
	cwd_state new_state;
	int ret;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, filename, NULL, 1);

	ret = chmod(new_state.cwd, mode);

	CWD_STATE_FREE(&new_state);
	return ret;
}

#if !defined(TSRM_WIN32) && !defined(NETWARE)
CWD_API int virtual_chown(const char *filename, uid_t owner, gid_t group TSRMLS_DC)
{
	cwd_state new_state;
	int ret;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, filename, NULL, 0);

	ret = chown(new_state.cwd, owner, group);

	CWD_STATE_FREE(&new_state);
	return ret;
}
#endif

CWD_API int virtual_open(const char *path TSRMLS_DC, int flags, ...)
{
	cwd_state new_state;
	int f;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, path, NULL, 1);

	if (flags & O_CREAT) {
		mode_t mode;
		va_list arg;

		va_start(arg, flags);
		mode = (mode_t) va_arg(arg, int);
		va_end(arg);

		f = open(new_state.cwd, flags, mode);
	} else {
		f = open(new_state.cwd, flags);
	}	
	CWD_STATE_FREE(&new_state);
	return f;
}

CWD_API int virtual_creat(const char *path, mode_t mode TSRMLS_DC)
{
	cwd_state new_state;
	int f;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, path, NULL, 1);

	f = creat(new_state.cwd,  mode);

	CWD_STATE_FREE(&new_state);
	return f;
}

CWD_API int virtual_rename(char *oldname, char *newname TSRMLS_DC)
{
	cwd_state old_state;
	cwd_state new_state;
	int retval;

	CWD_STATE_COPY(&old_state, &CWDG(cwd));
	virtual_file_ex(&old_state, oldname, NULL, 0);
	oldname = old_state.cwd;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, newname, NULL, 0);
	newname = new_state.cwd;
 
	retval = rename(oldname, newname);

	CWD_STATE_FREE(&old_state);
	CWD_STATE_FREE(&new_state);

	return retval;
}

CWD_API int virtual_stat(const char *path, struct stat *buf TSRMLS_DC)
{
	cwd_state new_state;
	int retval;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	if (virtual_file_ex(&new_state, path, NULL, 1)) {
		return -1;
	}

	retval = stat(new_state.cwd, buf);

	CWD_STATE_FREE(&new_state);
	return retval;
}

#ifndef TSRM_WIN32
CWD_API int virtual_lstat(const char *path, struct stat *buf TSRMLS_DC)
{
	cwd_state new_state;
	int retval;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, path, NULL, 0);

	retval = lstat(new_state.cwd, buf);

	CWD_STATE_FREE(&new_state);
	return retval;
}
#endif

CWD_API int virtual_unlink(const char *path TSRMLS_DC)
{
	cwd_state new_state;
	int retval;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, path, NULL, 0);

	retval = unlink(new_state.cwd);

	CWD_STATE_FREE(&new_state);
	return retval;
}

CWD_API int virtual_mkdir(const char *pathname, mode_t mode TSRMLS_DC)
{
	cwd_state new_state;
	int retval;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, pathname, NULL, 1);

#ifdef TSRM_WIN32
	retval = mkdir(new_state.cwd);
#else
	retval = mkdir(new_state.cwd, mode);
#endif
	CWD_STATE_FREE(&new_state);
	return retval;
}

CWD_API int virtual_rmdir(const char *pathname TSRMLS_DC)
{
	cwd_state new_state;
	int retval;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, pathname, NULL, 0);

	retval = rmdir(new_state.cwd);

	CWD_STATE_FREE(&new_state);
	return retval;
}

#ifdef TSRM_WIN32
DIR *opendir(const char *name);
#endif

CWD_API DIR *virtual_opendir(const char *pathname TSRMLS_DC)
{
	cwd_state new_state;
	DIR *retval;

	CWD_STATE_COPY(&new_state, &CWDG(cwd));
	virtual_file_ex(&new_state, pathname, NULL, 1);

	retval = opendir(new_state.cwd);

	CWD_STATE_FREE(&new_state);
	return retval;
}

#ifdef TSRM_WIN32

CWD_API FILE *virtual_popen(const char *command, const char *type TSRMLS_DC)
{
	return popen_ex(command, type, CWDG(cwd).cwd, NULL);
}

#elif defined(NETWARE)

/* On NetWare, the trick of prepending "cd cwd; " doesn't work so we need to perform
   a VCWD_CHDIR() and mutex it
 */
CWD_API FILE *virtual_popen(const char *command, const char *type TSRMLS_DC)
{
	char prev_cwd[MAXPATHLEN];
	char *getcwd_result;
	FILE *retval;

	getcwd_result = VCWD_GETCWD(prev_cwd, MAXPATHLEN);
	if (!getcwd_result) {
		return NULL;
	}

#ifdef ZTS
	tsrm_mutex_lock(cwd_mutex);
#endif

	VCWD_CHDIR(CWDG(cwd).cwd);
	retval = popen(command, type);
	VCWD_CHDIR(prev_cwd);

#ifdef ZTS
	tsrm_mutex_unlock(cwd_mutex);
#endif

	return retval;
}

#else /* Unix */

CWD_API FILE *virtual_popen(const char *command, const char *type TSRMLS_DC)
{
	int command_length;
	int dir_length, extra = 0;
	char *command_line;
	char *ptr, *dir;
	FILE *retval;

	command_length = strlen(command);

	dir_length = CWDG(cwd).cwd_length;
	dir = CWDG(cwd).cwd;
	while (dir_length > 0) {
		if (*dir == '\'') extra+=3;
		dir++;
		dir_length--;
	}
	dir_length = CWDG(cwd).cwd_length;
	dir = CWDG(cwd).cwd;

	ptr = command_line = (char *) malloc(command_length + sizeof("cd '' ; ") + dir_length +extra+1+1);
	if (!command_line) {
		return NULL;
	}
	memcpy(ptr, "cd ", sizeof("cd ")-1);
	ptr += sizeof("cd ")-1;

	if (CWDG(cwd).cwd_length == 0) {
		*ptr++ = DEFAULT_SLASH;
	} else {
		*ptr++ = '\'';
		while (dir_length > 0) {
			switch (*dir) {
			case '\'':
				*ptr++ = '\'';
				*ptr++ = '\\';
				*ptr++ = '\'';
				/* fall-through */
			default:
				*ptr++ = *dir;
			}
			dir++;
			dir_length--;
		}
		*ptr++ = '\'';
	}
	
	*ptr++ = ' ';
	*ptr++ = ';';
	*ptr++ = ' ';

	memcpy(ptr, command, command_length+1);
	retval = popen(command_line, type);

	free(command_line);
	return retval;
}

#endif


CWD_API char *tsrm_realpath(const char *path, char *real_path TSRMLS_DC)
{
	cwd_state new_state;
	char cwd[MAXPATHLEN];

	if (!IS_ABSOLUTE_PATH(path, strlen(path)) &&
	    VCWD_GETCWD(cwd, MAXPATHLEN)) {
		new_state.cwd = strdup(cwd);
		new_state.cwd_length = strlen(cwd);
	} else {
		new_state.cwd = (char*)malloc(1);
		new_state.cwd[0] = '\0';
		new_state.cwd_length = 0;		
	}

	if (virtual_file_ex(&new_state, path, NULL, CWD_REALPATH)) {
		free(new_state.cwd);
		return NULL;
	}

	if (real_path) {
		int copy_len = new_state.cwd_length>MAXPATHLEN-1 ? MAXPATHLEN-1 : new_state.cwd_length;
		memcpy(real_path, new_state.cwd, copy_len);
		real_path[copy_len] = '\0';
		free(new_state.cwd);
		return real_path;
	} else {
		return new_state.cwd;
	}
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
